#ifndef PLAYER_H
#define PLAYER_H
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include "Lobby.h"
#ifdef _WIN32
#include <winsock2.h>
#else
#include <sys/socket.h>
#endif

//Timeout in ms
#define RESPONSE_TIMEOUT (20000)

class Lobby;

class Player {
public:
	/*bool operator()(Player* o1, Player* o2) {
		return o1->plSocket == o2->plSocket;
	}*/
	std::thread thr;
	clock_t LastAccess;
	Lobby* connectedLobby;
	int CheckPlayer();
	Player(SOCKET servSock,struct sockaddr_in plAdd, char buffer[], int Length, std::vector<Lobby*>& _lobbiesList, std::vector<Player*>& playersList, std::mutex* playerListLock);
private:
	std::vector<Lobby*>* lobbiesList;
	std::vector<Player*>* playersList;
	std::mutex* ListsLock;
	sockaddr_in plAddress;
	SOCKET serverSock;
	std::atomic<bool> isInLobby;
	std::mutex SocketLock;
	int innerID;
	int IsAllowed;

	void run(char buffer[], int Length);
	void SendLoadNextLevel();
	void SendResponce(int code, int Value);

	void AssignLobby(Lobby* lobby);
	int LeaveLobby();
	void EnterLobby();
	int ClearPlayer();
};
#endif
﻿#include <iostream>
#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif 
#include "Lobby.h"
#include <signal.h>


const int PORT = 8005;
int MaxPlayersPerLobby;

using namespace std;


class ConnectionListener {
public:
    vector<Lobby*> lobbies;
    vector<Player*> players;
    mutex playerListLock;

    ConnectionListener() : exit_flag(false), thr(&ConnectionListener::run, this)
    {
    }
    void TryStop() {
        exit_flag = true;
        shutdown(server_fd, 2);
        closesocket(server_fd);
        thr.join();
    }

    void TryRestart() {
        exit_flag = false;
        shutdown(server_fd, 2);
        closesocket(server_fd);
        thr = thread(&ConnectionListener::run, this);
    }

    bool IsRunning() {
        return !exit_flag;
    }

    ~ConnectionListener() {
        exit_flag = true;
        thr.join();
    }
    
#ifdef _WIN32
    int InitializeWSA() {
        WORD wVersionRequested;
        WSADATA wsaData;
        int err;
        wVersionRequested = MAKEWORD(2, 2);

        err = WSAStartup(wVersionRequested, &wsaData);
        if (err != 0) {
            return 1;
        }
        else
            return 0;
    }
#endif
private:
    atomic<bool> exit_flag;
    thread thr;
    atomic<SOCKET> server_fd = 0;
    struct sockaddr_in address;
    int addrlen = sizeof(address), state = 1;

    void child(std::vector<Lobby*>& _lobbies, std::vector<Player*>& _players, std::mutex* _playerListLock, int LobbyLimit, int *ChildsAmount) {
        char buffer[1024] = { 0 };
        while ((int)_lobbies.size() >= LobbyLimit) {
            struct sockaddr_in clientaddr;
            int Amount;
            try{
                if ((Amount = recvfrom(server_fd, buffer, sizeof(buffer), 0, (struct sockaddr*)&clientaddr, &addrlen)) < 0) {
                    if (WSAGetLastError() == WSAECONNRESET || WSAGetLastError() == WSAEINTR || WSAGetLastError() == WSAETIMEDOUT)
                        continue;
                    cout << "\033[1;31m" << "ChildListener: 'recvfrom' failed." << "\033[0m" << endl;
                    goto UnexpectedError;
                }
            }
            catch (const std::exception& e) {
                cout << "\033[1;31m" << "ChildListener: 'recvfrom' failed." << e.what() << "\033[0m" << endl;
                goto UnexpectedError;
            }
            //cout << inet_ntoa(clientaddr.sin_addr) << ":" << ntohs(clientaddr.sin_port) << endl;
            Player* player = new Player(server_fd, clientaddr, buffer, Amount, _lobbies, _players, _playerListLock);
        }
        cout << "\033[1;31m" << "Listener child: lobbies amout decreased!" << "\033[0m" << endl;
        _playerListLock->lock();
        *ChildsAmount -= 1;
        _playerListLock->unlock();
        ExitThread(0);
    UnexpectedError:
        cout << "\033[1;31m" << "(Child)Error code: " << WSAGetLastError() << "\033[0m" << endl;
        _playerListLock->lock();
        *ChildsAmount -= 1;
        _playerListLock->unlock();
        exit(WSAGetLastError());
    }

    void run() {
        //Initialization
        cout << "\033[1;31m" << "Listener: Initialization.." << "\033[0m" << endl;
        //SOCKET new_socket;
        DWORD timeout = 5 * 1000;
        char buffer[1024] = { 0 };
        int ChildsAmount = 1, StepForChildCreation  = 1;

#ifdef _WIN32
        if (InitializeWSA() != 0) {
            goto UnexpectedError;
        }
#endif
        // Creating socket file descriptor 
        if ((server_fd = socket(AF_INET, SOCK_DGRAM, 17)) == 0)
        {
            cout << "\033[1;31m" << "Listener: 'socket' failed." << "\033[0m" << endl;
            goto UnexpectedError;
        }
        // Setting socket options
        if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, "", sizeof("")) != 0)
        {
            cout << "\033[1;31m" << "Listener: 'setsockopt' failed." << "\033[0m" << endl;
            goto UnexpectedError;
        }
        if (setsockopt(server_fd, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout)) != 0)
        {
            cout << "\033[1;31m" << "Listener: 'setsockopt' failed." << "\033[0m" << endl;
            goto UnexpectedError;
        }

        address.sin_family = AF_INET;
        address.sin_addr.s_addr = INADDR_ANY;
        address.sin_port = htons(PORT);

        // Forcefully attaching socket to the port 8005
        if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0)
        {
            cout << "\033[1;31m" << "Listener: 'bind' failed." << "\033[0m" << endl;
            goto UnexpectedError;
        }

        cout << "\033[1;31m" << "Listener: Waiting for connections" << "\033[0m" << endl;
        while (!exit_flag) {            
            struct sockaddr_in clientaddr;
            int Amount;
            if ((Amount = recvfrom(server_fd, buffer, sizeof(buffer), 0, (struct sockaddr*)&clientaddr, &addrlen)) < 0) {
                if (WSAGetLastError() == WSAECONNRESET || WSAGetLastError() == WSAEINTR || WSAGetLastError() == WSAETIMEDOUT)
                    continue;
                cout << "\033[1;31m" << "Listener: 'recvfrom' failed." << "\033[0m" << endl;
                goto UnexpectedError;
            }
            //cout << inet_ntoa(clientaddr.sin_addr) << ":" << ntohs(clientaddr.sin_port) << endl;
            Player* player = new Player(server_fd, clientaddr, buffer, Amount, std::ref(lobbies), std::ref(players), &playerListLock); 
            if ((int)lobbies.size() >= (StepForChildCreation * (ChildsAmount != 0) ? ChildsAmount : 1)) {
                thread t1(&ConnectionListener::child, this, std::ref(lobbies), std::ref(players), &playerListLock, StepForChildCreation * (ChildsAmount > 0) ? ChildsAmount : 1, &ChildsAmount);
                cout << "\033[1;31m" << "Listener: child created." << "\033[0m" << endl;
                ChildsAmount++;
                t1.detach();
            }
        }
        //Close socket if thread is terminated
        cout << "\033[1;31m" << "Listener: Stopped!" << "\033[0m"  << endl;
        WSACleanup();
        return;
    UnexpectedError:
        cout << "\033[1;31m" << "Error code: " << WSAGetLastError() << "\033[0m" << endl;
        exit_flag = true;
        shutdown(server_fd, 2);
        closesocket(server_fd);
        exit(WSAGetLastError());
    }

    
};

void Help() {
    cout << " 0: Shutdown." << endl;
    cout << " 1: Restart listener." << endl;
    cout << " 2: Amount of active players." << endl;
    cout << " 3: Amount of active lobbies." << endl;
    cout << " 4: Change maximum amount of players per lobby." << endl;
    //cout << " 9: ." << endl;
}

void Cleanup(vector<Player*> *players, mutex *ListLock)
{
    int AmountP = 0, AmountL = 0, result;
    while (true) {
        AmountP = 0; AmountL = 0;
        Sleep(20000);
        cout << "Clean up.." << endl;
        ListLock->lock();
        RefreshList:
        for (auto player : *players) {
            result = player->CheckPlayer();
            if (result > 2) {
                AmountL++;
                AmountP++;
                goto RefreshList;
            }
            else if (result > 0) {
                AmountP++;
                goto RefreshList;
            }
        }
        ListLock->unlock();
        cout << "Cleaned - " << AmountP << " players, " << AmountL << " lobbies." << endl;
    }
}

int main()
{
    cout << "Enter maximum players per lobby: ";
    cin >> MaxPlayersPerLobby;
    cout << endl;
    int Code;
    ConnectionListener Listener;
    
    //Give some time for Listener to initialize
    Sleep(100);
    thread t1(Cleanup, &Listener.players, &Listener.playerListLock);
    t1.detach();
    //Check whether Listener is running
    if (!Listener.IsRunning()) {
        perror("Listener error");
        exit(EXIT_FAILURE);
    }

    cout << "Enter '9' for list of commands." << endl;
    while (true) {
        cout << "Enter code: " << endl;
        cin >> Code;
        switch (Code) {
            case 0: 
                cout << "Shutting down.." << endl;
                Listener.TryStop(); 
                exit(0);
            case 1: Listener.TryStop();
                Listener.TryRestart();
                //Give some time for Listener to initialize
                Sleep(100);
                if (!Listener.IsRunning()) {
                    perror("Listener error");
                    exit(EXIT_FAILURE);
                }
                    break;
            case 2:
                cout << "Players count: " << Listener.players.size() << endl;
                break;
            case 3:
                cout << "Lobbies count: " << Listener.lobbies.size() << endl;
                break;
            case 4:
                cout << "Enter maximum players per lobby" << endl;
                cin >> MaxPlayersPerLobby;
                break;
            case 9: Help(); break;
        }
    }
    return 0;
}





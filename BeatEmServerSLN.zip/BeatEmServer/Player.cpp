#include "Player.h"
#include <iostream>
#include <string>

#pragma region LobbyActions
void Player::AssignLobby(Lobby* lobby) {
	connectedLobby = lobby;
	int lobbyID = connectedLobby->AddPlayer(this);
	if (lobbyID < 0) {
		std::cout << "Error while adding player to lobby! Retrying.." << std::endl;
		connectedLobby = NULL;
		EnterLobby();
	}
	else {
		innerID = lobbyID;
		IsAllowed = 1;
		isInLobby = true;
	}	
}

int Player::LeaveLobby() {
	int result = 1;
	if (connectedLobby->RemovePlayer(this) == 0) {
		if (int lobbyId = connectedLobby->EraseLobby(std::ref(lobbiesList)) != -1) {
			result = 2;
			delete(connectedLobby);
		}
		else {
			std::cout << "Failed to remove lobby!" << std::endl;
			result = -1;
		}
	}
	connectedLobby = NULL;
	isInLobby = false;
	innerID = 0;
	return result;
}

void Player::EnterLobby() {
	if (!lobbiesList->empty()) {
		for (auto lobby : *lobbiesList) {
			if (lobby->ActivePlayers < lobby->MaxPlayers && !lobby->IsClosed) {
				AssignLobby(lobby);
				break;
			}	
		}
		if (connectedLobby == NULL)
			goto CreateNew;
	}
	else {
		CreateNew:
		Lobby* newLobby = new Lobby();
		lobbiesList->push_back(newLobby);
		AssignLobby(newLobby);
	}
}
#pragma endregion

#pragma region ConstructorDestructor
Player::Player(SOCKET servSock,struct sockaddr_in plAdd, char buff[], int Length, std::vector<Lobby*>& _lobbiesList,
	std::vector<Player*>& _playersList, std::mutex* playerListLock) : thr(&Player::run, this,buff, Length), isInLobby(false), connectedLobby(NULL), innerID(0) {
	lobbiesList = &_lobbiesList;
	playersList = &_playersList;
	ListsLock = playerListLock;
	IsAllowed = 1;
	plAddress = plAdd;
	serverSock = servSock;
	LastAccess = clock();
	thr.detach();
}
#pragma endregion

int Player::ClearPlayer() {
	if (this == NULL) return -1;
	try {
		std::vector<Player*>::iterator it = find(playersList->begin(), playersList->end(), this);
		if (it != playersList->end())
		{
			int id = distance(playersList->begin(), it);
			std::shared_ptr<Player> temp = std::shared_ptr<Player>(playersList->at(id));
			playersList->erase(playersList->begin() + id);
			return 1;
		}
		else {
			std::cout << "Error while removing player from the list!" << std::endl;
			return -1;
		}
	}
	catch (const std::exception& e) {
		std::cout << e.what() << std::endl;
		return -1;
	}
}

static double diffclock(clock_t clock1, clock_t clock2)
{
	float diffticks = clock2 - clock1;
	double diffms = (diffticks) / (CLOCKS_PER_SEC / 1000);
	return diffms;
}

void Player::run(char mesbuffer[], int mesLength) {
#pragma region Initialization
	int adrlen = sizeof(plAddress);
	Player* thisPlayer = NULL;
	if (this->playersList == NULL) ExitThread(0);
	ListsLock->lock();
	for (auto player : *this->playersList) {
		if (inet_ntoa(player->plAddress.sin_addr) == inet_ntoa(this->plAddress.sin_addr) && ntohs(player->plAddress.sin_port) == ntohs(this->plAddress.sin_port)) {
			thisPlayer = player;
		}
	}
	if (thisPlayer == NULL) {
		this->playersList->push_back(this);
		thisPlayer = this;
	}
	ListsLock->unlock();
#pragma endregion
	thisPlayer->LastAccess = clock();

	if (mesLength > 0) {
		thisPlayer->LastAccess = clock();
		if (mesLength < 50) {
			std::cout << "Received code: " << std::atoi(mesbuffer) << std::endl;
			switch (std::atoi(mesbuffer)) {
				//Idling null code
			case 0:
				break;
				//Player enter queue
			case 20:
				thisPlayer->EnterLobby();
				thisPlayer->SendResponce(20, thisPlayer->innerID);
				thisPlayer->SendResponce(21, thisPlayer->connectedLobby->Seed);
				if (thisPlayer->connectedLobby->ActivePlayers == thisPlayer->connectedLobby->MaxPlayers) {
					//thisPlayer->connectedLobby->IsClosed = true;
					thisPlayer->SendLoadNextLevel();
				}
				break;
				//Player is ready
			case 21:
				thisPlayer->connectedLobby->PlayersReady++;
				if (thisPlayer->connectedLobby->PlayersReady == thisPlayer->connectedLobby->MaxPlayers) {
					for (auto player : thisPlayer->connectedLobby->playersList) {
						if (player != NULL) {
							player->SocketLock.lock();
							player->SendResponce(23, 0);
							player->SocketLock.unlock();
						}
					}
					thisPlayer->connectedLobby->NextRoundMaxPlayers /= 2;
					if (thisPlayer->connectedLobby->NextRoundMaxPlayers <= 8)
						thisPlayer->connectedLobby->NextRoundMaxPlayers = 1;
				}
				break;
				//Player finished level
			case 22:
				thisPlayer->IsAllowed = thisPlayer->connectedLobby->PlayerFinished();
				if (thisPlayer->IsAllowed == 0) break;
				if (thisPlayer->connectedLobby->NextRoundMaxPlayers == 1 && thisPlayer->IsAllowed == 1) {
					thisPlayer->SendResponce(24, 0);
					break;
				}
				else if (thisPlayer->connectedLobby->NextRoundMaxPlayers == thisPlayer->connectedLobby->NextRoundPlayerPool)
					thisPlayer->SendLoadNextLevel();
				break;
				//Leave lobby
			case 29:
				thisPlayer->LeaveLobby();
				break;
			}
		}
		else {
			if (thisPlayer->isInLobby) {
				for (auto player : thisPlayer->connectedLobby->playersList) {
					if (player != NULL && player->innerID != thisPlayer->innerID) {
						try {
							player->SocketLock.lock();
							sendto(serverSock, mesbuffer, mesLength, 0, (struct sockaddr*)&player->plAddress, adrlen);
							if (mesLength > 500)
								std::cout << "Bytes read: " << mesLength << std::endl;
							player->SocketLock.unlock();
						}
						catch (const std::exception& e) {
							std::cout << e.what() << std::endl;
							player->SocketLock.unlock();
						}
					}
				}
			}
		}
	}
	
}

#pragma region ServerResponces

void Player::SendResponce(int code, int Val) {
	char idd[11];
	int adrlen = sizeof(plAddress);
	sprintf_s(idd, 11, "%03d:%06d", code,Val);
	sendto(serverSock, idd, 11, 0, (struct sockaddr*)&plAddress, adrlen);
}

void Player::SendLoadNextLevel() {
	int adrlen = sizeof(plAddress);
	for (auto player : connectedLobby->playersList) {
		try {
			player->SocketLock.lock();
			player->IsAllowed = 0;
			player->SendResponce(22, player->IsAllowed);
			player->SocketLock.unlock();
		}
		catch (const std::exception& e) {
			std::cout << e.what() << std::endl;
			player->SocketLock.unlock();
		}
	}
}
#pragma endregion

int Player::CheckPlayer() {
	int result = 0;
	if (diffclock(LastAccess, clock()) >= RESPONSE_TIMEOUT) {
		std::cout << "Client left. Timeout." << std::endl;
		SocketLock.lock();
		if(isInLobby)
			result += LeaveLobby();
		SocketLock.unlock();
		result += ClearPlayer();
		return result;
	}
	return 0;
}


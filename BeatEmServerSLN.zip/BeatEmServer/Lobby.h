#ifndef LOBBY_H
#define LOBBY_H
#include <stdlib.h>
#include <vector>
#include <mutex>
#include "Player.h"

class Player;

/// <summary>
/// Defines amount of players per lobby.
/// </summary>
extern int MaxPlayersPerLobby;

class Lobby {
public:
	bool IsClosed;
	int MaxPlayers;
	int ActivePlayers;
	int PlayersReady = 0;
	int NextRoundPlayerPool;
	int NextRoundMaxPlayers;
	int MaxRounds;
	int NextID;
	int Seed;
	std::vector<Player*> playersList;
	int RemovePlayer(Player* player);
	int AddPlayer(Player* player);
	void SetMaxPlayers(int maxPlayers);
	int PlayerFinished();
	int EraseLobby(std::vector<Lobby*>* _lobbiesList);
	int FindPlayerId(Player* player);
	Lobby();
private:
	std::mutex LobbyLock;
};
#endif
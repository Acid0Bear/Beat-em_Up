#include "Lobby.h"
#include <iostream>
using namespace std;

Lobby::Lobby() {
	this->MaxPlayers = MaxPlayersPerLobby;
	this->ActivePlayers = 0;
	this->NextID = 0;
	this->NextRoundMaxPlayers = this->MaxPlayers;
	this->MaxRounds = 2;
	this->NextRoundPlayerPool = 0;
	this->NextRoundMaxPlayers = this->MaxPlayers / 2;
	this->IsClosed = false;
	srand(time(NULL));
	this->Seed = rand() % 1000000;
}

#pragma region PlayerOPS
int Lobby::RemovePlayer(Player* player) {
	int id;
	if ((id = FindPlayerId(player)) < 0)
		return -1;
	else
	{
		LobbyLock.lock();
		playersList.erase(playersList.begin() + id);
		ActivePlayers--;
		LobbyLock.unlock();
		return ActivePlayers;
	}
}

int Lobby::PlayerFinished() {
	int result;
	LobbyLock.lock();
	if (this->NextRoundPlayerPool < this->NextRoundMaxPlayers) {
		this->NextRoundPlayerPool++;
		result = 1;
	}
	else
		result = 0;
	LobbyLock.unlock();
	return result;
}

int Lobby::AddPlayer(Player* player) {
	if (ActivePlayers == MaxPlayers) return -1;
	if (FindPlayerId(player) != -1)
		RemovePlayer(player);
	LobbyLock.lock();
	playersList.push_back(player);
	ActivePlayers++;
	NextID++;
	LobbyLock.unlock();
	return NextID;
}
int Lobby::FindPlayerId(Player* player) {
	vector<Player*>::iterator it = find(playersList.begin(), playersList.end(), player);
	if (it != playersList.end())
		return distance(playersList.begin(), it);
	else
		return -1;
}
#pragma endregion

#pragma region LobbyOPS
int Lobby::EraseLobby(std::vector<Lobby*>* _lobbiesList) {
	vector<Lobby*>::iterator it = find(_lobbiesList->begin(), _lobbiesList->end(), this);
	if (it != _lobbiesList->end())
	{
		int i = distance(_lobbiesList->begin(), it);
		_lobbiesList->erase((_lobbiesList->begin() + i));
		return 0;
	}
	else
	{
		return -1;
	}
}

void Lobby::SetMaxPlayers(int maxPlayers) {
	MaxPlayers = maxPlayers;
}
#pragma endregion